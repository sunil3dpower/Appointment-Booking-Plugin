<?php
function appointment_booking_form_shortcode() {
    ob_start();
    ?>
    <form id="appointment-form" method="post">
        <input type="text" placeholder="Name" id="name" name="name" required>
        <input type="email" placeholder="Email" id="email" name="email" required>
        <input type="number" placeholder="Mobile" id="mobile" name="mobile" required>

        <label for="calendar">Date:</label>
        <div id="calendar-container" class="container">
            <!-- Custom calendar will be injected here -->
            <div class="calendar-month block">
                <div class="arrow-btn-container">
                    <h2 id="calendar-title" class="titular">April 2023</h2>
                    <a class="arrow-btn left" id="prev-month" href="javascript:void(0);">
                    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path d="M15.54 18.46L10.12 13.04L15.54 7.62L14.12 6.2L7.12 13.2L14.12 20.2L15.54 18.46Z"/>
                        </svg>
                    </a>
                    <a class="arrow-btn right" id="next-month" href="javascript:void(0);">
                    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path d="M8.46 5.54L13.88 11.96L8.46 17.38L9.88 18.8L16.88 11.8L9.88 4.8L8.46 5.54Z"/>
                        </svg>
                    </a>
                </div>
                <table class="calendar">
                    <thead class="days-week">
                        <tr>
                            <th>S</th>
                            <th>M</th>
                            <th>T</th>
                            <th>W</th>
                            <th>T</th>
                            <th>F</th>
                            <th>S</th>
                        </tr>
                    </thead>
                    <tbody id="calendar-body">
                        <!-- Calendar days will be injected here -->
                    </tbody>
                </table>
            </div>
        </div>
        <input type="hidden" id="date" name="date" required>

        <label for="time">Time:</label>
        <select id="time" name="time" required>
            <option value="" disabled selected>Select a time slot</option>
            <?php
            // Define time slots
            $time_slots = [
                '09:00' => '09:00 AM',
                '10:00' => '10:00 AM',
                '11:00' => '11:00 AM',
                '12:00' => '12:00 PM',
                '01:00' => '01:00 PM',
                '02:00' => '02:00 PM',
                '03:00' => '03:00 PM',
                '04:00' => '04:00 PM',
                '05:00' => '05:00 PM',
                '06:00' => '06:00 PM',
                '07:00' => '07:00 PM'
            ];

            foreach ($time_slots as $value => $label) {
                echo "<option value=\"$value\">$label</option>";
            }
            ?>
        </select>

        <div id="appointment-booking-response"></div>
        <button type="submit">Book Appointment</button>
    </form>
    <?php
    return ob_get_clean();
}

add_shortcode('appointment_booking_form', 'appointment_booking_form_shortcode');
?>
