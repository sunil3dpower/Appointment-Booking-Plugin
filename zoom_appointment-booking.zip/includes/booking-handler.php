<?php

function handle_appointment_booking() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'appointments';
    $log_file = dirname(__FILE__) . '/appointment-booking-debug.log';

    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'appointment_booking_nonce')) {
        $message = "Invalid nonce";
        file_put_contents($log_file, $message . "\n", FILE_APPEND);
        wp_send_json_error($message);
        return;
    }

    // Log incoming data
    file_put_contents($log_file, "Received data: " . print_r($_POST, true) . "\n", FILE_APPEND);

    // Sanitize and validate data
    $name = sanitize_text_field($_POST['name']);
    $email = sanitize_email($_POST['email']);
    $mobile = sanitize_text_field($_POST['mobile']);
    $date = sanitize_text_field($_POST['date']);
    $time = sanitize_text_field($_POST['time']);

    // Log sanitized data
    file_put_contents($log_file, "Sanitized data: " . print_r([
        'name'  => $name,
        'email' => $email,
        'mobile' => $mobile,
        'date'  => $date,
        'time'  => $time
    ], true) . "\n", FILE_APPEND);

    // Check for required fields
    if (empty($name) || empty($email) || empty($mobile) || empty($date) || empty($time)) {
        $message = "All fields are required.";
        file_put_contents($log_file, "Error: " . $message . "\n", FILE_APPEND);
        wp_send_json_error($message);
        return;
    }
    
    // Validate mobile number
    if (!preg_match('/^\d{10}$/', $mobile)) {
        $message = "Mobile number must be exactly 10 digits.";
        file_put_contents($log_file, "Error: " . $message . "\n", FILE_APPEND);
        wp_send_json_error($message);
        return;
    }

    // Validate email
    if (!is_email($email)) {
        $message = "Invalid email address.";
        file_put_contents($log_file, "Error: " . $message . "\n", FILE_APPEND);
        wp_send_json_error($message);
        return;
    }

    // Compare dates using DateTime
    $current_date = new DateTime();
    $current_date->setTime(0, 0); // Set the time part to 00:00:00 for comparison
    $appointment_date = new DateTime($date);

    file_put_contents($log_file, "Current date: " . $current_date->format('Y-m-d') . "\n", FILE_APPEND);
    file_put_contents($log_file, "Appointment date: " . $appointment_date->format('Y-m-d') . "\n", FILE_APPEND);

    if ($appointment_date < $current_date) {
        $message = "The date cannot be in the past.";
        file_put_contents($log_file, "Error: " . $message . "\n", FILE_APPEND);
        wp_send_json_error($message);
        return;
    }

    // Check if time slot is available
    $existing_appointment = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE date = %s AND time = %s",
        $date, $time
    ));

    if ($existing_appointment) {
        $message = "The selected time slot is already booked.";
        file_put_contents($log_file, "Error: " . $message . "\n", FILE_APPEND);
        wp_send_json_error($message);
        return;
    }

    // Convert date and time to ISO 8601 format
    $datetimeString = "$date $time:00";
    $start_time = new DateTime($datetimeString, new DateTimeZone('Asia/Kolkata'));
    $start_time_iso = $start_time->format(DateTime::ATOM);

    // Prepare Zoom API request
    $api_url = 'https://rumzz.com/zoom/create_meeting.php';  
    $meetingDetails = [
        "topic" => "Meeting with $name",
        "start_time" => $start_time_iso,  // ISO 8601 format
        "duration" => 60,
        "timezone" => 'Asia/Kolkata',  // Set timezone to India Standard Time
        "password" => wp_generate_password(8, true, true),  // Generate a random password
        "agenda" => "Meeting scheduled with $name.",
    ];

    $response = wp_remote_post($api_url, [
        'method'    => 'POST',
        'body'      => json_encode($meetingDetails),
        'headers'   => [
            'Content-Type' => 'application/json',
        ],
    ]);

    if (is_wp_error($response)) {
        $message = "Failed to create Zoom meeting: " . $response->get_error_message();
        file_put_contents($log_file, "Error: " . $message . "\n", FILE_APPEND);
        wp_send_json_error($message);
        return;
    }

    $meeting = json_decode(wp_remote_retrieve_body($response), true);
    
    file_put_contents($log_file, $meeting['start_url'] . "\n", FILE_APPEND);
    
    if (isset($meeting['join_url']) && isset($meeting['start_url'])) {
        // Insert appointment into table with Zoom meeting details
        $result = $wpdb->insert(
            $table_name,
            [
                'name'  => $name,
                'email' => $email,
                'mobile' => $mobile,
                'date'  => $date,
                'time'  => $time,
                'zoom_link' => $meeting['join_url'],
                'zoom_start_url' => $meeting['start_url'] // Save the start URL
            ],
            [
                '%s', // name
                '%s', // email
                '%s', // mobile
                '%s', // date
                '%s', // time
                '%s', // zoom_link
                '%s'  // zoom_start_url
            ]
        );

        if ($result === false) {
            $message = "Database insert failed: " . $wpdb->last_error;
            file_put_contents($log_file, "Error: " . $message . "\n", FILE_APPEND);
            wp_send_json_error($message);
            return;
        }

        file_put_contents($log_file, "Insert Result: Success\n", FILE_APPEND);

        // Site owner email
        $site_owner_email = get_option('admin_email');

        // Send confirmation email to customer
        $customer_subject = 'Meeting Confirmation';
        $customer_message = "Your Meeting has been booked for $date at $time.\n\nJoin URL: {$meeting['join_url']}";
        $email_sent = wp_mail($email, $customer_subject, $customer_message);
        file_put_contents($log_file, "Email to customer: " . ($email_sent ? "Sent" : "Failed") . "\n", FILE_APPEND);

        // Send email to site owner
        $owner_subject = 'New Meeting Booking';
        $owner_message = "A new Meeting has been booked. Here are the details:\n\nName: $name\nEmail: $email\nMobile: $mobile\nDate: $date\nTime: $time\n\nJoin URL: {$meeting['join_url']}\nHost URL: {$meeting['start_url']}";
        $owner_email_sent = wp_mail($site_owner_email, $owner_subject, $owner_message);
        file_put_contents($log_file, "Email to site owner: " . ($owner_email_sent ? "Sent" : "Failed") . "\n", FILE_APPEND);

        wp_send_json_success('Meeting booked successfully');
    } else {
        $message = "Failed to retrieve Zoom meeting details.";
        file_put_contents($log_file, "Error: " . $message . "\n", FILE_APPEND);
        wp_send_json_error($message);
    }
}
