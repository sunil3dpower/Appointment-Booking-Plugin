jQuery(document).ready(function($) {
    // Set the minimum date for the date picker to today
    var today = new Date().toISOString().split('T')[0];
    $('#date').attr('min', today);
    console.log('Minimum date set to:', today);

    // Handle form submission
    $('#appointment-form').on('submit', function(e) {
        e.preventDefault();

        var name = $('#name').val().trim();
        var email = $('#email').val().trim();
        var mobile = $('#mobile').val().trim();
        var date = $('#date').val().trim();
        var time = $('#time').val().trim();
        var responseDiv = $('#appointment-booking-response');

        // Clear previous response messages and error classes
        responseDiv.html('').removeClass('error success');
        $('input, select').removeClass('error');

        var hasError = false;

        // Validate mobile number
        if (!/^\d{10}$/.test(mobile)) {
            responseDiv.html('Mobile number must be exactly 10 digits.').addClass('error');
            $('#mobile').addClass('error');
            hasError = true;
        }

        // Validate email address
        if (!/^[\w-\.]+@([\w-]+\.)+[a-zA-Z]{2,}$/.test(email)) {
            responseDiv.html('Invalid email address.').addClass('error');
            $('#email').addClass('error');
            hasError = true;
        }

        // Validate date
        if (!date) {
            responseDiv.html('Date is required.').addClass('error');
            $('#date').addClass('error');
            hasError = true;
        }

        // Validate time
        if (!time) {
            responseDiv.html('Time is required.').addClass('error');
            $('#time').addClass('error');
            hasError = true;
        }

        // If there are validation errors, stop the form submission
        if (hasError) {
            return;
        }

        // Prepare form data for AJAX request
        var formData = {
            action: 'submit_appointment_booking',
            nonce: appointmentBooking.nonce,
            name: name,
            email: email,
            mobile: mobile,
            date: date,
            time: time
        };

        // Send AJAX request to submit the appointment booking
        $.ajax({
            url: appointmentBooking.ajax_url,
            method: 'POST',
            data: formData,
            success: function(response) {
                if (response.success) {
                    responseDiv.html('Appointment booked successfully!').addClass('success');
                    $('#appointment-form')[0].reset();
                    $('#date').attr('min', today); // Reset the min date

                    // Re-fetch available slots to reflect the new booking
                    checkAvailableSlots(date);
                } else {
                    responseDiv.html('Error: ' + (response.data || 'Unknown error')).addClass('error');
                }
            },
            error: function(xhr, status, error) {
                responseDiv.html('An error occurred. Please try again.').addClass('error');
                console.error('AJAX Error:', status, error);
            }
        });
    });

    // Remove error class and message on input/change
    $('#appointment-form input, #appointment-form select').on('input change', function() {
        $(this).removeClass('error');
        $('#appointment-booking-response').html('').removeClass('error success');
    });

    // Handle click event on calendar-day link
    $(document).on('click', '.calendar-day', function(e) {
        e.preventDefault();
        var selectedDate = $(this).data('date');
        console.log('Date selected from calendar:', selectedDate);
        checkAvailableSlots(selectedDate);
    });

    function checkAvailableSlots(date) {
        var data = {
            action: 'check_available_slots',
            nonce: appointmentBooking.nonce,
            date: date
        };

        $.post(appointmentBooking.ajax_url, data, function(response) {
            console.log('Available slots response:', response);

            if (response.success) {
                var bookedSlots = response.data.booked_slots;
                console.log('Booked slots:', bookedSlots);

                // Show/hide time options based on booked slots
                $('#time option').each(function() {
                    var slot = $(this).val();
                    if (bookedSlots.includes(slot)) {
                        $(this).hide();
                    } else {
                        $(this).show();
                    }
                });

                // Ensure at least one option is visible and selected
                $('#time').find('option:visible').first().prop('selected', true);
            } else {
                $('#appointment-booking-response').html('Failed to fetch available slots.').addClass('error');
            }
        }).fail(function(jqXHR, textStatus, errorThrown) {
            console.log('AJAX request failed:', textStatus, errorThrown);
            $('#appointment-booking-response').html('Failed to fetch available slots.').addClass('error');
        });
    }

});


document.addEventListener('DOMContentLoaded', () => {
    const calendarTitle = document.getElementById('calendar-title');
    const calendarBody = document.getElementById('calendar-body');
    const prevMonthButton = document.getElementById('prev-month');
    const nextMonthButton = document.getElementById('next-month');
    const hiddenDateInput = document.getElementById('date');
    const timeSelect = document.getElementById('time');

    let currentDate = new Date();
    let earliestAllowedDate = new Date(); // Default to current date

    function fetchApiTime() {
        fetch('http://worldtimeapi.org/api/ip') // Replace with your API endpoint
            .then(response => response.json())
            .then(data => {
                const apiTime = new Date(data.datetime);
                earliestAllowedDate.setTime(apiTime.getTime());
                earliestAllowedDate.setHours(0, 0, 0, 0); // Normalize to start of day
                currentDate = new Date(apiTime); // Set current date to API time
                renderCalendar(currentDate);
            })
            .catch(error => {
                console.error('Error fetching API time:', error);
                earliestAllowedDate = new Date(); // Fallback to current time
                earliestAllowedDate.setHours(0, 0, 0, 0); // Normalize to start of day
                renderCalendar(currentDate);
            });
    }

    function renderCalendar(date) {
        calendarBody.innerHTML = '';

        const month = date.getMonth();
        const year = date.getFullYear();
        const options = { month: 'long', year: 'numeric' };
        calendarTitle.innerText = date.toLocaleDateString('en-US', options);

        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const daysInMonth = lastDay.getDate();
        const firstDayIndex = firstDay.getDay();

        let day = 1;

        for (let i = 0; i < 6; i++) {
            const row = document.createElement('tr');

            for (let j = 0; j < 7; j++) {
                const cell = document.createElement('td');

                if (i === 0 && j < firstDayIndex) {
                    cell.classList.add('empty');
                } else if (day > daysInMonth) {
                    cell.classList.add('empty');
                } else {
                    const cellDate = new Date(year, month, day);
                    const today = new Date();
                    today.setHours(0, 0, 0, 0); // Normalize today's date to 00:00:00

                    // Check if the cell date is in the past and in the current month
                    const isPastDate = cellDate < earliestAllowedDate;

                    if (isPastDate) {
                        cell.innerHTML = `<span class="calendar-day disabled">${day}</span>`;
                        cell.classList.add('disabled');
                    } else {
                        cell.innerHTML = `<a href="#" class="calendar-day" data-date="${year}-${month + 1}-${day}">${day}</a>`;
                    }
                    day++;
                }
                row.appendChild(cell);
            }
            calendarBody.appendChild(row);
        }

        updateButtonState();
    }

    function changeMonth(direction) {
        if (direction === 'prev') {
            const prevMonthDate = new Date(currentDate);
            prevMonthDate.setMonth(currentDate.getMonth() - 1);
            
            // Allow navigation to previous month if it's within the range of the earliest allowed date
            if (prevMonthDate >= earliestAllowedDate || (prevMonthDate.getFullYear() > earliestAllowedDate.getFullYear())) {
                currentDate.setMonth(currentDate.getMonth() - 1);
                renderCalendar(currentDate);
            }
        } else {
            currentDate.setMonth(currentDate.getMonth() + 1);
            renderCalendar(currentDate);
        }
    }

    function updateButtonState() {
        const prevMonthDate = new Date(currentDate);
        prevMonthDate.setMonth(currentDate.getMonth() - 1);
        
        // Disable the previous month button if the previous month is before the earliest allowed date
        if (prevMonthDate < earliestAllowedDate) {
            prevMonthButton.disabled = true;
            prevMonthButton.classList.add('disabled');
        } else {
            prevMonthButton.disabled = false;
            prevMonthButton.classList.remove('disabled');
        }
    }

    function updateSelectState() {
        const selectedDate = document.querySelector('.calendar-day.selected');
        if (selectedDate) {
            timeSelect.querySelectorAll('option').forEach(option => {
                option.disabled = false;
                timeSelect.disabled = false;
            });
            timeSelect.selectedIndex = 1;
            setTimeout(() => {
                timeSelect.focus();
                timeSelect.size = 12;
            }, 100);
        } else {
            timeSelect.querySelectorAll('option').forEach(option => {
                option.disabled = true;
                timeSelect.disabled = true;
            });
        }
    }

    function handleDateSelection(event) {
        if (event.target.classList.contains('calendar-day') && !event.target.classList.contains('disabled')) {
            event.preventDefault();
            const selectedDate = event.target.getAttribute('data-date');
            hiddenDateInput.value = selectedDate;
            console.log('Selected Date:', selectedDate);
            document.querySelectorAll('.calendar-day.selected').forEach(day => {
                day.classList.remove('selected');
            });
            event.target.classList.add('selected');
            updateSelectState();
        }
    }

    prevMonthButton.addEventListener('click', () => changeMonth('prev'));
    nextMonthButton.addEventListener('click', () => changeMonth('next'));
    calendarBody.addEventListener('click', handleDateSelection);

    fetchApiTime();
});



document.addEventListener('DOMContentLoaded', function() {
    function disableTimeSlotsIfToday(apiTime) {
        const selectedDateElement = document.querySelector('.calendar-day.selected');
        const selectElement = document.getElementById('time');
        
        if (selectedDateElement && selectElement) {
            const selectedDateStr = selectedDateElement.getAttribute('data-date');
            const [year, month, day] = selectedDateStr.split('-').map(Number);
            const selectedDate = new Date(year, month - 1, day); // Months are 0-indexed in JavaScript Date

            const apiDate = new Date(apiTime);
            const todayDate = new Date(apiDate.getFullYear(), apiDate.getMonth(), apiDate.getDate());
            const isToday = selectedDate.getTime() === todayDate.getTime();

            console.log(`Selected date: ${selectedDate.toISOString().split('T')[0]}`);
            console.log(`Today's date (from API): ${todayDate.toISOString().split('T')[0]}`);
            console.log(`Is today: ${isToday}`);

            // Reset all options to enabled
            Array.from(selectElement.options).forEach(option => option.disabled = false);

            // If the selected date is today, proceed with disabling time slots
            if (isToday) {
                const now = new Date(apiTime);
                const currentHour = now.getHours();
                const currentMinutes = now.getMinutes();
                const currentTimeInMinutes = currentHour * 60 + currentMinutes;

                console.log(`Current time from API: ${currentHour}:${currentMinutes} (${currentTimeInMinutes} minutes)`);

                const options = selectElement.options;
                for (let i = 1; i < options.length; i++) { // Start from 1 to skip the first disabled option
                    const [optionHourStr, optionMinutes] = options[i].value.split(':');
                    let optionHour = Number(optionHourStr);
                    const isPM = options[i].text.includes('PM');
                    // Handle 12-hour format
                    if (optionHour === 12 && !isPM) {
                        optionHour = 0; // Midnight
                    } else if (isPM && optionHour !== 12) {
                        optionHour += 12; // Convert PM hours
                    }
                    const optionTimeInMinutes = optionHour * 60 + Number(optionMinutes);

                    console.log(`Option ${options[i].text}: ${optionHour}:${optionMinutes} (${optionTimeInMinutes} minutes)`);

                    // Disable options that are less than or equal to current time + 60 minutes
                    if (optionTimeInMinutes <= currentTimeInMinutes + 60) {
                        console.log(`Disabling option: ${options[i].text}`);
                        options[i].disabled = true;
                    } else {
                        console.log(`Enabling option: ${options[i].text}`);
                        options[i].disabled = false;
                    }
                }
            } else {
                console.log('Selected date is not today. No time slots will be disabled.');
            }
        } else {
            console.log('No selected date element or select element found.');
        }
    }

    function fetchTimeAndUpdate() {
        fetch('http://worldtimeapi.org/api/ip')
            .then(response => response.json())
            .then(data => {
                const apiTime = data.datetime;
                console.log("Fetched API time: ", apiTime);

                disableTimeSlotsIfToday(apiTime);
            })
            .catch(error => console.error('Error fetching time:', error));
    }

    // Add event listener to dynamically handle date selection
    document.addEventListener('click', function(event) {
        if (event.target.matches('.calendar-day')) {
            // Add/remove 'selected' class to the clicked date
            document.querySelectorAll('.calendar-day').forEach(el => el.classList.remove('selected'));
            event.target.classList.add('selected');

            console.log('Date selected:', event.target.getAttribute('data-date'));

            // Fetch time and then call function to disable time slots
            fetchTimeAndUpdate();
        }
    });
});





document.addEventListener('DOMContentLoaded', () => {
    const timeSelect = document.getElementById('time');
    const calendarDays = document.querySelectorAll('.calendar-day');
    
    const updateSelectState = () => {
        const selectedDate = document.querySelector('.calendar-day.selected');
        if (selectedDate) {
            // Enable all options
            timeSelect.querySelectorAll('option').forEach(option => {
                option.disabled = false;
                timeSelect.disabled = false;
            });

            // Optionally, select the first enabled option to force dropdown to open
            timeSelect.selectedIndex = 1;
            setTimeout(() => {
                timeSelect.focus();
                timeSelect.size = 12; // Expand dropdown height
            }, 100);
        } else {
            // Disable all options if no date is selected
            timeSelect.querySelectorAll('option').forEach(option => {
                option.disabled = true;
                timeSelect.disabled = true;
            });
        }
    };

    calendarDays.forEach(day => {
        day.addEventListener('click', (event) => {
            event.preventDefault();
            
            // Remove selected class from all calendar days
            calendarDays.forEach(d => d.classList.remove('selected'));
            
            // Add selected class to the clicked day
            day.classList.add('selected');
            
            // Update the state of the select dropdown
            updateSelectState();
        });
    });

    // Initial state update on page load
    updateSelectState();
});
