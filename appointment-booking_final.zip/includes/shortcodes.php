<?php
function appointment_booking_form_shortcode() {
    ob_start();
    ?>
<form id="appointment-form" method="post">
    <div class="input-split">
        <input type="text" placeholder="Name" id="name" name="name" required>
        <input type="number" placeholder="Mobile" id="mobile" name="mobile" required>
    </div>
    <input type="email" placeholder="Email" id="email" name="email" required>

    <div class="booking-container">
        <div class="calendar-area">
            <label for="calendar">Date:</label>
            <div id="calendar-container" class="container">
                <!-- Custom calendar will be injected here -->
                <div class="calendar-month block">
                    <div class="calendar-header">
                        <h2 id="calendar-title" class="titular">April 2023</h2>
                        <div class="arrow-btn-container">
                            <a class="arrow-btn left disabled" id="prev-month" href="javascript:void(0);">
                                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M15.41 16.59L10.83 12L15.41 7.41L14 6L8 12L14 18L15.41 16.59Z" />
                                </svg>
                            </a>
                           <a class="arrow-btn right" id="next-month" href="javascript:void(0);">
                                <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M8.59 16.59L13.17 12L8.59 7.41L10 6L16 12L10 18L8.59 16.59Z" />
                                </svg>
                            </a>
                        </div>
                    </div>

                    <table class="calendar">
                        <thead class="days-week">
                            <tr>
                                <th>SUN</th>
                                <th>MON</th>
                                <th>TUE</th>
                                <th>WED</th>
                                <th>THU</th>
                                <th>FRI</th>
                                <th>SAT</th>
                            </tr>
                        </thead>
                        <tbody id="calendar-body">
                            <!-- Calendar days will be injected here -->
                        </tbody>
                    </table>
                </div>
            </div>
            <input type="hidden" id="date" name="date" required>
        </div>

        <div class="time-slot-area">
            <label for="time">Time:</label>
            <div class="select-wrapper">
            <select id="time" name="time" required>
                <option value="" disabled selected>Select a time slot</option>
                <?php
            // Define time slots
            $time_slots = [
                '09:00' => '09:00 AM',
                '10:00' => '10:00 AM',
                '11:00' => '11:00 AM',
                '12:00' => '12:00 PM',
                '01:00' => '01:00 PM',
                '02:00' => '02:00 PM',
                '03:00' => '03:00 PM',
                '04:00' => '04:00 PM',
                '05:00' => '05:00 PM',
                '06:00' => '06:00 PM',
                '07:00' => '07:00 PM'
            ];

            foreach ($time_slots as $value => $label) {
                echo "<option value=\"$value\">$label</option>";
            }
            ?>
            </select>
            </div>
            
        </div>

    </div>


    <div class="form-footer">
        <div id="appointment-booking-response"></div>
        <button type="submit">Book Appointment</button>
    </div>

</form>
<?php
    return ob_get_clean();
}

add_shortcode('appointment_booking_form', 'appointment_booking_form_shortcode');
?>