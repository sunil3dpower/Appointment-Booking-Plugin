<?php
/*
Plugin Name: Appointment Booking
Description: A plugin to handle appointment bookings with AJAX validation.
Version: 1.0
Author: Sunil Bedke
License: GPL2
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Include necessary files
include_once(plugin_dir_path(__FILE__) . 'includes/booking-handler.php');
include_once(plugin_dir_path(__FILE__) . 'includes/shortcodes.php');

// Register activation hook
register_activation_hook(__FILE__, 'appointment_booking_activate');
function appointment_booking_activate() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'appointments';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        name varchar(255) NOT NULL,
        mobile varchar(255) NOT NULL,
        email varchar(255) NOT NULL,
        date date NOT NULL,
        time varchar(10) NOT NULL,
        PRIMARY KEY (id),
        UNIQUE KEY (date, time)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Register deactivation hook
register_deactivation_hook(__FILE__, 'appointment_booking_deactivate');
function appointment_booking_deactivate() {
    // Optionally, you can drop the table or perform other cleanup actions here
    flush_rewrite_rules();
}

// Enqueue scripts and styles
function appointment_booking_enqueue_scripts() {
    // Enqueue the JavaScript file
    wp_enqueue_script('appointment-booking-js', plugin_dir_url(__FILE__) . 'assets/js/appointment-booking.js', array('jquery'), null, true);

    // Pass PHP variables to JavaScript
    wp_localize_script('appointment-booking-js', 'appointmentBooking', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('appointment_booking_nonce'),
    ));

    // Enqueue CSS file (if needed)
    wp_enqueue_style('appointment-booking-css', plugin_dir_url(__FILE__) . 'assets/css/appointment-booking.css');
}
add_action('wp_enqueue_scripts', 'appointment_booking_enqueue_scripts');

function check_available_slots() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'appointments';
    $log_file = dirname(__FILE__) . '/appointment-booking-debug.log';

    // Log request start
    file_put_contents($log_file, "Checking available slots at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND);

    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'appointment_booking_nonce')) {
        file_put_contents($log_file, "Error: Invalid nonce\n", FILE_APPEND);
        wp_send_json_error('Invalid nonce');
        return;
    }

    // Sanitize date input
    $date = sanitize_text_field($_POST['date']);
    file_put_contents($log_file, "Checked date: " . $date . "\n", FILE_APPEND);

    // Fetch booked slots for the selected date
    $booked_slots = $wpdb->get_col($wpdb->prepare(
        "SELECT time FROM $table_name WHERE date = %s",
        $date
    ));

    file_put_contents($log_file, "Booked slots: " . print_r($booked_slots, true) . "\n", FILE_APPEND);

    wp_send_json_success(['booked_slots' => $booked_slots]);
}


// Register AJAX actions
add_action('wp_ajax_submit_appointment_booking', 'handle_appointment_booking');
add_action('wp_ajax_nopriv_submit_appointment_booking', 'handle_appointment_booking');
add_action('wp_ajax_check_available_slots', 'check_available_slots');
add_action('wp_ajax_nopriv_check_available_slots', 'check_available_slots');
