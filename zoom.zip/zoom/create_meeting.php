<?php

// Function to obtain access token using Server-to-Server OAuth
function getAccessToken() {
    $clientId = '2sCBkm9qT7a9kIGn2m7sAg';  // Your Zoom Client ID
    $clientSecret = 'NaU0CtfskNGW3bQjeayrzdJW14F6Wyrv';  // Your Zoom Client Secret
    $accountId = 'xOepYRc6TxmihZRpu8Vu8w';  // Your Zoom Account ID

    $tokenUrl = "https://zoom.us/oauth/token?grant_type=account_credentials&account_id={$accountId}";

    $authHeader = base64_encode($clientId . ':' . $clientSecret);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $tokenUrl);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Authorization: Basic ' . $authHeader,
        'Content-Type: application/x-www-form-urlencoded'
    ));

    $response = curl_exec($ch);
    curl_close($ch);

    $body = json_decode($response, true);
    if (isset($body['access_token'])) {
        return $body['access_token'];
    } else {
        die('Failed to obtain access token. Response: ' . $response);
    }
}

// Function to create Zoom meeting using the Zoom API
function createZoomMeeting($meetingDetails) {
    $accessToken = getAccessToken();
    $apiUrl = 'https://api.zoom.us/v2/users/me/meetings';

    $headers = array(
        'Authorization: Bearer ' . $accessToken,
        'Content-Type: application/json'
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($meetingDetails));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}

// Get POST data
$input = file_get_contents('php://input');
$meetingDetails = json_decode($input, true);

// Validate meeting details
if (isset($meetingDetails['topic']) && isset($meetingDetails['start_time']) && isset($meetingDetails['duration'])) {
    // Create meeting
    $response = createZoomMeeting($meetingDetails);
    header('Content-Type: application/json');
    echo $response;
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid meeting details']);
}
