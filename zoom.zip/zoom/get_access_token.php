<?php
$clientId = '2sCBkm9qT7a9kIGn2m7sAg';  // Your Zoom Client ID
$clientSecret = 'NaU0CtfskNGW3bQjeayrzdJW14F6Wyrv';  // Your Zoom Client Secret

$tokenUrl = 'https://zoom.us/oauth/token';
$params = array(
    'grant_type' => 'client_credentials'
);

$authHeader = base64_encode($clientId . ':' . $clientSecret);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $tokenUrl);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($params));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Authorization: Basic ' . $authHeader,
    'Content-Type: application/x-www-form-urlencoded'
));

$response = curl_exec($ch);
curl_close($ch);

$body = json_decode($response, true);
if (isset($body['access_token'])) {
    // Save the access token securely
    file_put_contents('access_token.json', json_encode($body));
    echo 'Access token obtained successfully.';
} else {
    echo 'Failed to obtain access token. Response: ' . $response;
}
?>
